export default function Profile() {
  return (
    <div>Profile</div>
  )
}
