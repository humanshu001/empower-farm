import { BuyCard } from "./BuyCards";

export default function Buy(){
    return(
        <>
            <h1 className="text-center text-4xl font-black py-6 px-3">Buy Leftover Products by Fellow Farmers</h1>
        <div className="flex justify-center items-center container flex-wrap">
          
        <BuyCard title="Urea ka katta" description="12 kilo urea rheta h mere paas kisi ko bhi chahiye ho bata do" imageUrl="https://picsum.photos/1600/900" price={100} mobile={9034710039} whatsapp={8930963832}/>
        <BuyCard title="Urea ka katta" description="12 kilo urea rheta h mere paas kisi ko bhi chahiye ho bata do" imageUrl="https://picsum.photos/1600/900" price={100} mobile={9034710039} whatsapp={8930963832}/>
        <BuyCard title="Urea ka katta" description="12 kilo urea rheta h mere paas kisi ko bhi chahiye ho bata do" imageUrl="https://picsum.photos/1600/900" price={100} mobile={9034710039} whatsapp={8930963832}/>
        <BuyCard title="Urea ka katta" description="12 kilo urea rheta h mere paas kisi ko bhi chahiye ho bata do" imageUrl="https://picsum.photos/1600/900" price={100} mobile={9034710039} whatsapp={8930963832}/>
        <BuyCard title="Urea ka katta" description="12 kilo urea rheta h mere paas kisi ko bhi chahiye ho bata do" imageUrl="https://picsum.photos/1600/900" price={100} mobile={9034710039} whatsapp={8930963832}/>
        <BuyCard title="Urea ka katta" description="12 kilo urea rheta h mere paas kisi ko bhi chahiye ho bata do" imageUrl="https://picsum.photos/1600/900" price={100} mobile={9034710039} whatsapp={8930963832}/>
        <BuyCard title="Urea ka katta" description="12 kilo urea rheta h mere paas kisi ko bhi chahiye ho bata do" imageUrl="https://picsum.photos/1600/900" price={100} mobile={9034710039} whatsapp={8930963832}/>
        </div>
        </>
    )
}